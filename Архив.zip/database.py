import os
from datetime import datetime
from pymongo import MongoClient
from dotenv import load_dotenv
import sqlite3

load_dotenv()

class Database:
    def __init__(self):
        # Подключение к MongoDB
        mongo_uri = os.getenv('MONGODB_URI', 'mongodb://localhost:27017/')
        self.client = MongoClient(mongo_uri)
        self.db = self.client['theta_healer_db']
        
        # Коллекции
        self.users = self.db['users']
        self.messages = self.db['messages']
        
        # Создание индексов
        self.messages.create_index([("user_id", 1)])
        self.users.create_index([("user_id", 1)], unique=True)

    def create_user(self, user_id: int, username: str):
        """Создание нового пользователя или обновление существующего"""
        self.users.update_one(
            {"user_id": user_id},
            {
                "$set": {
                    "username": username,
                    "last_active": datetime.utcnow(),
                    "created_at": datetime.utcnow()
                }
            },
            upsert=True
        )

    def save_message(self, user_id: int, text: str, is_user: bool):
        """Сохранение сообщения в базу данных"""
        message = {
            "user_id": user_id,
            "text": text,
            "is_user": is_user,
            "timestamp": datetime.utcnow()
        }
        self.messages.insert_one(message)
        
        # Обновление времени последней активности пользователя
        self.users.update_one(
            {"user_id": user_id},
            {"$set": {"last_active": datetime.utcnow()}}
        )

    def get_chat_history(self, user_id: int, limit: int = 10):
        """Получение истории чата пользователя"""
        return list(
            self.messages.find(
                {"user_id": user_id},
                {"_id": 0, "text": 1, "is_user": 1, "timestamp": 1}
            )
            .sort("timestamp", -1)
            .limit(limit)
        )

    def get_user_info(self, user_id: int):
        """Получение информации о пользователе"""
        return self.users.find_one({"user_id": user_id}, {"_id": 0})

    def update_user_status(self, user_id: int, status: dict):
        """Обновление статуса пользователя"""
        self.users.update_one(
            {"user_id": user_id},
            {"$set": {
                "status": status,
                "last_active": datetime.utcnow()
            }}
        )

def init_db():
    """Инициализация базы данных"""
    conn = sqlite3.connect('theta_healer.db')
    c = conn.cursor()
    
    # Создаем таблицу для ответов пользователей
    c.execute('''
        CREATE TABLE IF NOT EXISTS user_responses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            direction TEXT NOT NULL,
            response_text TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()

def save_user_response(user_id: int, direction: str, response_text: str):
    """Сохранение ответа пользователя"""
    conn = sqlite3.connect('theta_healer.db')
    c = conn.cursor()
    
    c.execute('''
        INSERT INTO user_responses (user_id, direction, response_text)
        VALUES (?, ?, ?)
    ''', (user_id, direction, response_text))
    
    conn.commit()
    conn.close()

def get_user_responses(user_id: int):
    """Получение всех ответов пользователя"""
    conn = sqlite3.connect('theta_healer.db')
    c = conn.cursor()
    
    c.execute('''
        SELECT direction, response_text, created_at
        FROM user_responses
        WHERE user_id = ?
        ORDER BY created_at DESC
    ''', (user_id,))
    
    responses = c.fetchall()
    conn.close()
    
    return responses 