import logging
from database import init_db

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

def main():
    """Основная функция инициализации базы данных"""
    logger.info("🚀 Начинаем инициализацию базы данных...")
    
    try:
        # Инициализируем базу данных
        init_db()
        logger.info("✅ База данных успешно инициализирована!")
        
    except Exception as e:
        logger.error(f"❌ Ошибка при инициализации базы данных: {e}")
        logger.error("❌ Не удалось инициализировать базу данных")
        return False
    
    return True

if __name__ == "__main__":
    main() 