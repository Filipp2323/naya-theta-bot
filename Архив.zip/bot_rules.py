"""
Правила и конфигурация для Telegram бота Тета-Хилер

Этот файл содержит основные правила работы бота, настройки и важные константы.
"""

# Правила обработки сообщений
MESSAGE_HANDLING_RULES = {
    "state_tracking": {
        "enabled": True,
        "description": "Отслеживание состояния пользователя через user_states",
        "implementation": """
        - Хранить текущий шаг пользователя
        - Сохранять данные сессии
        - Отслеживать последнее сообщение
        """
    },
    "duplicate_prevention": {
        "enabled": True,
        "description": "Предотвращение повторной обработки одинаковых сообщений",
        "implementation": """
        - Проверять last_message в состоянии пользователя
        - Игнорировать повторные сообщения
        """
    },
    "history_storage": {
        "enabled": True,
        "description": "Сохранение истории в базу данных",
        "implementation": """
        - Сохранять все сообщения пользователя
        - Сохранять текущий шаг сессии
        - Использовать для контекста в OpenAI
        """
    },
    "context_awareness": {
        "enabled": True,
        "description": "Использование контекста текущего шага при работе с OpenAI",
        "implementation": """
        - Передавать текущий шаг в промпт
        - Использовать историю сообщений
        - Поддерживать контекст беседы
        """
    },
    "error_handling": {
        "enabled": True,
        "description": "Правильная обработка ошибок и очистка ресурсов",
        "implementation": """
        - Логировать все ошибки
        - Очищать файлы блокировки при остановке
        - Корректно завершать процессы
        """
    }
}

# Настройки запуска бота
BOT_STARTUP_RULES = {
    "instance_control": {
        "check_running": True,
        "cleanup_on_start": True,
        "lock_file_path": "/tmp/theta_bot.lock",
        "pid_file_path": "theta_bot.pid"
    },
    "resource_cleanup": {
        "remove_lock_files": True,
        "kill_old_processes": True,
        "cleanup_delay": 2  # seconds
    }
}

# Настройки OpenAI
OPENAI_SETTINGS = {
    "model": "gpt-4-turbo-preview",
    "temperature": 0.7,
    "max_tokens": 1000,
    "timeout": 60.0,
    "retry_attempts": 3
}

# Настройки базы данных
DATABASE_SETTINGS = {
    "save_responses": True,
    "max_history_length": 5,  # количество последних сообщений для контекста
    "cleanup_interval": 7  # дней, через сколько удалять старые записи
}

def validate_rules():
    """Проверка правил и настроек"""
    for category in [MESSAGE_HANDLING_RULES, BOT_STARTUP_RULES, 
                    OPENAI_SETTINGS, DATABASE_SETTINGS]:
        if not category:
            raise ValueError("Отсутствует обязательная категория правил")
    return True 