#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Telegram Bot "Ная" - Theta Healer Bot
Адаптированная версия для хостинга Amvera.ru
"""

import os
import sys
import logging
import asyncio
from datetime import datetime
from typing import Dict, Any

# Telegram Bot API
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters
from telegram.ext import CommandHandler as TelegramCommandHandler

# OpenAI API
from openai import OpenAI

# Environment variables
from dotenv import load_dotenv

# Database
from database import init_db, save_user_response

# Bot components
from bot_commands import BotKeyboards, BotMessages

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# OpenAI settings
OPENAI_SETTINGS = {
    'model': 'gpt-4',
    'temperature': 0.7,
    'timeout': 30
}

class ThetaBot:
    def __init__(self):
        """Инициализация бота"""
        # Загрузка переменных окружения
        self.token = os.getenv('TELEGRAM_TOKEN')
        if not self.token:
            raise ValueError("TELEGRAM_TOKEN не найден в переменных окружения")
            
        self.openai_key = os.getenv('OPENAI_API_KEY')
        if not self.openai_key:
            raise ValueError("OPENAI_API_KEY не найден в переменных окружения")
        
        # Инициализация хранилищ состояний
        self.session_states = {}
        self.user_states = {}
        
        # Инициализация OpenAI клиента
        try:
            self.client = OpenAI(
                api_key=self.openai_key,
                timeout=OPENAI_SETTINGS['timeout']
            )
            logger.info("OpenAI клиент успешно инициализирован")
        except Exception as e:
            logger.error(f"Ошибка при инициализации OpenAI клиента: {e}")
            raise
        
        # Инициализация базы данных
        try:
            init_db()
            logger.info("База данных успешно инициализирована")
        except Exception as e:
            logger.error(f"Ошибка при инициализации базы данных: {e}")
            raise

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Обработка команды /start с красивым приветствием"""
        try:
            # Краткое приветственное сообщение с описанием услуг
            welcome_message = (
                "✨ *Добро пожаловать в мир глубинных трансформаций!* ✨\n\n"
                "Меня зовут Ная, и я ваш проводник в удивительное путешествие к истинному Я через метод Тета-хилинга.\n\n"
                "🌟 *Что умеет этот бот:*\n"
                "• ✨ Персональные тета-сессии для раскрытия потенциала\n"
                "• 🌌 Прямое общение с мудростью Вселенной\n"
                "• 🧘‍♀️ Медитации на каждый день недели\n"
                "• 📝 Отзывы и истории трансформации\n"
                "• 💬 Прямая связь с Наей для личных консультаций\n\n"
                "🔮 Готовы открыть дверь к своему внутреннему миру?"
            )
            
            # Создаем красивую кнопку "Старт"
            keyboard = [[InlineKeyboardButton("✨ Начать путешествие ✨", callback_data="start_journey")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            # Отправляем приветствие
            await update.message.reply_text(
                welcome_message,
                parse_mode='Markdown',
                reply_markup=reply_markup
            )
            logger.info("Отправлено приветствие")
                
        except Exception as e:
            logger.error(f"Error in start: {e}")
            # Отправляем простое сообщение в случае ошибки
            try:
                await update.message.reply_text(
                    "✨ Добро пожаловать! Я Ная, ваш проводник в мир Тета-хилинга.\n\n"
                    "Выберите действие из меню:",
                    reply_markup=BotKeyboards.get_main_menu()
                )
            except Exception as fallback_error:
                logger.error(f"Fallback error in start: {fallback_error}")

    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка входящих сообщений"""
        if not update.message or not update.message.text:
            return

        user_id = update.effective_user.id
        text = update.message.text.strip()
        
        try:
            # Проверяем контекст сессии
            session_context = context.user_data.get('session_context', {})
            universe_context = context.user_data.get('universe_context', {})
            
            # Если это ответ на вопросы тета-сессии
            if session_context.get('waiting_for_response') and session_context.get('questions_asked'):
                await self.handle_session_response(update, context)
                return
            
            # Если это вопрос к Вселенной
            if universe_context.get('waiting_for_question'):
                await self.handle_universe_response(update, context)
                return
            
            # Обработка команд из главного меню
            if text == "🌌 Задать вопрос Вселенной":
                await self.handle_universe_question(update, context)
                return
            elif text == "✨ Начать сессию":
                await self.start_session(update, context)
                return
            elif text == "🧘‍♀️ Медитации":
                await self.handle_meditations(update, context)
                return
            elif text == "📝 Отзывы":
                await self.handle_testimonials(update, context)
                return
            elif text == "❓ Частые вопросы":
                await self.handle_faq(update, context)
                return
            elif text == "💬 Задать вопрос Нае":
                await self.handle_contact_naya(update, context)
                return
            elif text == "⬅️ Вернуться в главное меню":
                await self.start(update, context)
                return
            elif text in ["🌟 Раскрытие потенциала", "❤️ Гармония в отношениях", 
                         "💰 Финансовое благополучие", "🧘‍♀️ Здоровье и энергия"]:
                await self.handle_session_choice(update, context)
                return
            
            # Если не распознали команду, показываем главное меню
            await update.message.reply_text(
                "Выберите действие из меню:",
                reply_markup=BotKeyboards.get_main_menu()
            )
            
        except Exception as e:
            logger.error(f"Ошибка при обработке сообщения: {e}")
            await self.handle_error(update, BotMessages.ERROR_MESSAGE)

    async def handle_session_response(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка ответа на вопросы тета-сессии"""
        message_text = update.message.text
        
        # Сохраняем ответ пользователя
        context.user_data['user_response'] = message_text
        
        # Отправляем сообщение о готовности ответа
        response_message = (
            "✨ Благодарю за ваши искренние ответы!\n\n"
            "Я прочувствовала вашу ситуацию и готова поделиться глубоким пониманием и направить вас к раскрытию вашего истинного потенциала.\n\n"
            "Нажмите кнопку ниже, чтобы получить моё видение вашего пути. ♥️"
        )
        
        # Создаем клавиатуру с кнопкой "Получить ответ"
        keyboard = BotKeyboards.get_answer_button()
        
        # Отправляем сообщение с кнопкой
        await update.message.reply_text(
            response_message,
            reply_markup=keyboard
        )
        
        # Обновляем контекст
        context.user_data['session_context']['waiting_for_response'] = False

    async def handle_universe_response(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка вопроса к Вселенной"""
        message_text = update.message.text
        
        # Сохраняем вопрос
        context.user_data['universe_question'] = message_text
        
        # Отправляем сообщение о получении вопроса
        response_message = (
            "✨ Я получила ваш вопрос и готова передать его Вселенной.\n\n"
            "Сейчас я настроюсь на высшие вибрации и помогу вам получить ответ "
            "из самого источника мудрости.\n\n"
            "Нажмите кнопку ниже, чтобы получить ответ Вселенной. ♥️"
        )
        
        # Создаем клавиатуру с кнопкой
        keyboard = [[InlineKeyboardButton("Получить ответ Вселенной ✨", callback_data="get_universe_answer")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            response_message,
            reply_markup=reply_markup
        )
        
        # Очищаем контекст ожидания вопроса
        context.user_data['universe_context']['waiting_for_question'] = False

    async def handle_testimonials(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Отзывы клиентов"""
        testimonials = (
            "*📝 Отзывы наших клиентов:*\n\n"
            "🌟 _\"Ная помогла мне найти свой путь. Теперь я чувствую себя более уверенно и знаю, чего хочу от жизни.\"_ - Анна\n\n"
            "✨ _\"Сессия с Наей изменила мое отношение к деньгам. Теперь я привлекаю изобилие легко и естественно.\"_ - Михаил\n\n"
            "💖 _\"Благодаря работе с Наей я исцелила отношения с родителями и нашла любовь.\"_ - Елена\n\n"
            "🎯 _\"Тета-хилинг с Наей помог мне раскрыть творческий потенциал и найти свое призвание.\"_ - Дмитрий\n\n"
            "_Хотите поделиться своим опытом? Напишите нам!_"
        )
        await update.message.reply_text(testimonials, parse_mode='Markdown')

    async def handle_faq(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Часто задаваемые вопросы"""
        faq = (
            "*❓ Часто задаваемые вопросы:*\n\n"
            "*Что такое Тета-хилинг?*\n"
            "Это метод энергетического исцеления, который работает с подсознанием через состояние тета-волн мозга.\n\n"
            "*Как проходит сессия?*\n"
            "Каждая сессия уникальна и адаптирована под ваши потребности. Мы работаем с глубинными убеждениями, исцеляем эмоциональные травмы и активируем ваш внутренний потенциал.\n\n"
            "*Сколько сессий необходимо?*\n"
            "Это индивидуально и зависит от вашего запроса. Помните, что каждая сессия - это шаг к вашему истинному Я.\n\n"
            "*Это безопасно?*\n"
            "Абсолютно. Мы работаем только с любовью и высшими вибрациями, учитывая ваш темп и готовность к изменениям.\n\n"
            "*Как подготовиться к сессии?*\n"
            "Просто будьте открыты изменениям и доверяйте процессу. Всё необходимое уже есть внутри вас.\n\n"
            "_Есть другие вопросы? Задайте их Нае лично!_"
        )
        await update.message.reply_text(faq, parse_mode='Markdown')

    async def handle_contact_naya(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Перенаправление к личному чату с Наей"""
        contact_message = (
            "💬 *Хотите задать вопрос лично Нае?*\n\n"
            "✨ Нажмите на кнопку ниже, чтобы перейти в личный чат с Наей "
            "и получить индивидуальную консультацию.\n\n"
            "🌟 Ная с радостью ответит на ваши вопросы и поможет выбрать "
            "подходящий формат работы для вашей уникальной ситуации.\n\n"
            "💎 _Каждое обращение - это шаг к вашему истинному Я!_"
        )
        
        # Создаем кнопку для перехода в личный чат
        keyboard = [[InlineKeyboardButton("💬 Написать Нае", url="https://t.me/Annastasiya90")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            contact_message,
            parse_mode='Markdown',
            reply_markup=reply_markup
        )

    async def handle_universe_question(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка запроса на вопрос к Вселенной"""
        universe_message = (
            "🌌 *Канал связи с Вселенной открыт* ✨\n\n"
            "Дорогая душа, я готова стать проводником между вами и бесконечной мудростью Вселенной.\n\n"
            "💫 Задайте свой вопрос, и я передам его в высшие сферы, "
            "где обитает вся мудрость и знание.\n\n"
            "🔮 _Помните: Вселенная всегда отвечает тем, кто искренне ищет истину._"
        )
        
        # Устанавливаем контекст ожидания вопроса
        context.user_data['universe_context'] = {'waiting_for_question': True}
        
        await update.message.reply_text(universe_message, parse_mode='Markdown')

    async def start_session(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Начало тета-сессии"""
        session_intro = BotMessages.SESSION_INTRO
        keyboard = BotKeyboards.get_session_menu()
        
        await update.message.reply_text(
            session_intro,
            parse_mode='Markdown',
            reply_markup=keyboard
        )

    async def handle_session_choice(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Обработка выбора типа сессии"""
        session_type = update.message.text
        
        # Определяем тип сессии
        theta_sessions = {
            "🌟 Раскрытие потенциала": "potential",
            "❤️ Гармония в отношениях": "relationships", 
            "💰 Финансовое благополучие": "finance",
            "🧘‍♀️ Здоровье и энергия": "health"
        }
        
        if session_type in theta_sessions:
            # Сохраняем тип сессии
            context.user_data['session_type'] = theta_sessions[session_type]
            
            # Задаем три стандартных вопроса
            questions = (
                f"✨ *Прекрасно! Вы выбрали: {session_type}*\n\n"
                "Для создания наиболее точного и глубокого ответа, "
                "я хочу задать вам три важных вопроса:\n\n"
                "💫 **1. Что вас больше всего беспокоит в этой сфере жизни?**\n\n"
                "🌟 **2. Какой результат вы хотели бы получить?**\n\n"
                "🔮 **3. Что, по вашему мнению, мешает вам достичь желаемого?**\n\n"
                "_Ответьте на все три вопроса в одном сообщении, и я дам вам глубокий персональный ответ._"
            )
            
            # Устанавливаем контекст сессии
            context.user_data['session_context'] = {
                'waiting_for_response': True,
                'questions_asked': True
            }
            
            await update.message.reply_text(questions, parse_mode='Markdown')

    async def handle_callback_query(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Обработка нажатий на inline кнопки"""
        query = update.callback_query
        await query.answer()
        
        try:
            if query.data == "start_journey":
                # Показываем главное меню
                journey_message = (
                    "🌟 *Добро пожаловать в ваше духовное путешествие!*\n\n"
                    "Я здесь, чтобы поддержать вас на пути к истинному Я. "
                    "Каждый шаг этого путешествия наполнен любовью и светом.\n\n"
                    "💫 Выберите, что резонирует с вашей душой прямо сейчас:"
                )
                
                await query.message.reply_text(
                    journey_message,
                    parse_mode='Markdown',
                    reply_markup=BotKeyboards.get_main_menu()
                )
            
            elif query.data == "get_answer":
                # Получаем ответ от GPT для тета-сессии
                user_response = context.user_data.get('user_response', '')
                session_type = context.user_data.get('session_type', '')
                
                if user_response:
                    # Генерируем ответ
                    gpt_response = await self.generate_gpt_response(user_response)
                    
                    # Сохраняем в базу данных
                    try:
                        save_user_response(
                            user_id=update.effective_user.id,
                            username=update.effective_user.username or "Unknown",
                            session_type=session_type,
                            user_response=user_response,
                            bot_response=gpt_response
                        )
                    except Exception as db_error:
                        logger.error(f"Ошибка сохранения в БД: {db_error}")
                    
                    # Отправляем ответ пользователю
                    await query.message.reply_text(
                        gpt_response,
                        parse_mode='Markdown',
                        reply_markup=BotKeyboards.get_main_menu()
                    )
                    
                    # Очищаем контекст
                    context.user_data.pop('session_context', None)
                    context.user_data.pop('user_response', None)
                    context.user_data.pop('session_type', None)
                else:
                    await query.message.reply_text(
                        "Произошла ошибка. Попробуйте начать сессию заново."
                    )
            
            elif query.data == "get_universe_answer":
                # Получаем ответ от Вселенной
                universe_question = context.user_data.get('universe_question', '')
                
                if universe_question:
                    # Генерируем ответ Вселенной
                    universe_response = await self.generate_universe_response(universe_question)
                    
                    # Отправляем ответ
                    await query.message.reply_text(
                        universe_response,
                        parse_mode='Markdown',
                        reply_markup=BotKeyboards.get_main_menu()
                    )
                    
                    # Очищаем контекст
                    context.user_data.pop('universe_context', None)
                    context.user_data.pop('universe_question', None)
                else:
                    await query.message.reply_text(
                        "Произошла ошибка. Попробуйте задать вопрос заново."
                    )
            
            elif query.data.startswith("meditation_"):
                # Обработка выбора медитации
                await self.handle_meditation_choice(query, context)
                
        except Exception as e:
            logger.error(f"Ошибка в handle_callback_query: {e}")
            await query.message.reply_text(
                "Произошла ошибка. Попробуйте еще раз.",
                reply_markup=BotKeyboards.get_main_menu()
            )

    async def handle_error(self, update: Update, error_message: str) -> None:
        """Обработка ошибок"""
        try:
            await update.message.reply_text(
                error_message,
                reply_markup=BotKeyboards.get_main_menu()
            )
        except Exception as e:
            logger.error(f"Ошибка при отправке сообщения об ошибке: {e}")

    async def generate_universe_response(self, question: str) -> str:
        """Генерация ответа от Вселенной через OpenAI"""
        try:
            # Промпт для ответа от Вселенной
            universe_prompt = f"""
            Ты - мудрая и любящая Вселенная, которая отвечает на вопросы людей через канал Нии - практика тета-хилинга.
            
            Твой стиль ответа:
            - Глубокий, мудрый, полный любви и понимания
            - Используй метафоры и образы
            - Говори от первого лица как Вселенная
            - Давай конкретные советы и направления
            - Завершай подписью "С безграничной любовью, Вселенная ✨"
            
            Вопрос человека: {question}
            
            Дай глубокий, мудрый ответ от имени Вселенной.
            """
            
            # Асинхронный вызов OpenAI
            def get_openai_response():
                response = self.client.chat.completions.create(
                    model=OPENAI_SETTINGS['model'],
                    messages=[{"role": "user", "content": universe_prompt}],
                    temperature=OPENAI_SETTINGS['temperature'],
                    max_tokens=500
                )
                return response.choices[0].message.content.strip()
            
            # Выполняем в отдельном потоке
            loop = asyncio.get_event_loop()
            response_text = await loop.run_in_executor(None, get_openai_response)
            
            return response_text
            
        except Exception as e:
            logger.error(f"Ошибка при генерации ответа Вселенной: {e}")
            return (
                "💫 *Дорогая душа,*\n\n"
                "В данный момент энергетические потоки немного нестабильны. "
                "Попробуйте задать вопрос чуть позже, когда связь восстановится.\n\n"
                "Помните: ответ уже живет в вашем сердце. Прислушайтесь к себе. ✨\n\n"
                "_С любовью, Вселенная_ 💫"
            )

    async def generate_gpt_response(self, user_response: str) -> str:
        """Генерация персонального ответа через OpenAI"""
        try:
            # Промпт для Нии
            naya_prompt = f"""
            Ты - Ная, мудрая и любящая практик тета-хилинга. Твоя задача - дать глубокий, персональный ответ на вопросы клиента.
            
            Твой стиль:
            - Говори с любовью и пониманием
            - Используй духовные термины: "душа", "энергия", "вибрации", "истинное Я"
            - Давай конкретные советы и практики
            - Используй эмодзи для акцентов
            - Будь поддерживающей и вдохновляющей
            - Максимум 150-200 символов
            - Завершай подписью "С ♥️ Ная"
            
            Ответ клиента: {user_response}
            
            Дай глубокий персональный ответ от имени Нии.
            """
            
            # Асинхронный вызов OpenAI
            def get_openai_response():
                response = self.client.chat.completions.create(
                    model=OPENAI_SETTINGS['model'],
                    messages=[{"role": "user", "content": naya_prompt}],
                    temperature=OPENAI_SETTINGS['temperature'],
                    max_tokens=250
                )
                return response.choices[0].message.content.strip()
            
            # Выполняем в отдельном потоке
            loop = asyncio.get_event_loop()
            response_text = await loop.run_in_executor(None, get_openai_response)
            
            return response_text
            
        except Exception as e:
            logger.error(f"Ошибка при генерации ответа GPT: {e}")
            return (
                "✨ *Дорогая душа,*\n\n"
                "Я чувствую вашу энергию и вижу ваш путь. В данный момент "
                "энергетические потоки требуют немного времени для стабилизации.\n\n"
                "Попробуйте обратиться чуть позже, и я смогу дать вам более "
                "глубокий и точный ответ.\n\n"
                "С ♥️ Ная"
            )

    async def handle_meditations(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка раздела медитаций"""
        meditation_message = (
            "🧘‍♀️ *Добро пожаловать в пространство медитаций!*\n\n"
            "Здесь вы найдете медитации для каждого дня недели, "
            "каждая из которых настроена на особую энергию и задачи дня.\n\n"
            "✨ Выберите медитацию, которая резонирует с вашей душой:"
        )
        
        # Создаем клавиатуру с медитациями
        keyboard = [
            [InlineKeyboardButton("🌅 Понедельник - Новые начинания", callback_data="meditation_monday")],
            [InlineKeyboardButton("🌸 Вторник - Творческий поток", callback_data="meditation_tuesday")],
            [InlineKeyboardButton("💎 Среда - Внутренняя мудрость", callback_data="meditation_wednesday")],
            [InlineKeyboardButton("💚 Четверг - Сердечная гармония", callback_data="meditation_thursday")],
            [InlineKeyboardButton("🌟 Пятница - Изобилие и процветание", callback_data="meditation_friday")],
            [InlineKeyboardButton("🌙 Суббота - Глубокое исцеление", callback_data="meditation_saturday")],
            [InlineKeyboardButton("☀️ Воскресенье - Духовное единение", callback_data="meditation_sunday")],
            [InlineKeyboardButton("🔮 Медитация дня", callback_data="meditation_today")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            meditation_message,
            parse_mode='Markdown',
            reply_markup=reply_markup
        )

    async def handle_meditation_choice(self, query, context):
        """Обработка выбора конкретной медитации"""
        try:
            # Получаем день медитации из callback_data
            meditation_day = query.data.replace("meditation_", "")
            
            # Словарь медитаций (сокращенная версия)
            meditations = {
                "monday": {
                    "text": (
                        "🌅 *Медитация \"Новые начинания\"*\n\n"
                        "✨ Сядьте удобно, закройте глаза и сделайте три глубоких вдоха...\n\n"
                        "🌱 Представьте себя стоящим на пороге нового дня, новой недели, новых возможностей.\n\n"
                        "💪 Почувствуйте, как в вашем теле пробуждается энергия созидания и действия.\n\n"
                        "🎯 Визуализируйте свои цели яркими и четкими, словно они уже воплощены в реальность.\n\n"
                        "⚡ Повторяйте: \"Я полон энергии и готов к новым свершениям. Каждый мой шаг ведет к успеху.\"\n\n"
                        "_Длительность: 15-20 минут_\n"
                        "_С любовью, Ная_ ♥️"
                    )
                },
                "tuesday": {
                    "text": (
                        "🌸 *Медитация \"Творческий поток\"*\n\n"
                        "🎨 Закройте глаза и представьте себя в прекрасном саду творчества...\n\n"
                        "🌈 Вокруг вас текут потоки разноцветной энергии вдохновения.\n\n"
                        "✨ Позвольте этим потокам войти в ваше сердце и разум.\n\n"
                        "🎭 Почувствуйте, как пробуждается ваша творческая сущность.\n\n"
                        "🌺 Повторяйте: \"Я - канал для бесконечного творческого потока. Через меня проявляется красота Вселенной.\"\n\n"
                        "_Длительность: 15-20 минут_\n"
                        "_С любовью, Ная_ ♥️"
                    )
                },
                "today": {
                    "text": (
                        "🔮 *Медитация дня*\n\n"
                        "✨ Сегодня ваша душа сама выберет нужную энергию...\n\n"
                        "🌈 Закройте глаза и прислушайтесь к своему внутреннему голосу.\n\n"
                        "💎 Какая энергия нужна вам сегодня? Сила? Любовь? Мудрость?\n\n"
                        "🌟 Позвольте этой энергии наполнить ваше существо.\n\n"
                        "🦋 Повторяйте: \"Я принимаю именно то, что нужно моей душе сегодня.\"\n\n"
                        "_Длительность: 15-20 минут_\n"
                        "_С любовью, Ная_ ♥️"
                    )
                }
            }
            
            meditation = meditations.get(meditation_day)
            if meditation:
                await query.message.reply_text(
                    meditation["text"],
                    parse_mode='Markdown'
                )
            else:
                await query.message.reply_text(
                    "Простите, эта медитация временно недоступна. Попробуйте выбрать другую. ✨"
                )
            
            await query.answer()
            
        except Exception as e:
            logger.error(f"Ошибка в handle_meditation_choice: {e}")
            await query.message.reply_text(
                "Простите, произошла ошибка при загрузке медитации. Попробуйте еще раз."
            )
            await query.answer()

    def run(self):
        """Запуск бота для хостинга"""
        try:
            logger.info("🔄 Подготовка к запуску бота на хостинге...")
            
            # Создаем и настраиваем приложение
            application = Application.builder().token(self.token).build()

            # Добавляем обработчики команд
            application.add_handler(TelegramCommandHandler("start", self.start))
            application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message))
            application.add_handler(CallbackQueryHandler(self.handle_callback_query))

            # Запускаем бота
            logger.info("✅ Бот успешно запущен на хостинге!")
            
            # Запускаем бота в режиме polling
            application.run_polling(allowed_updates=Update.ALL_TYPES)
            
        except Exception as e:
            logger.error(f"❌ Критическая ошибка: {str(e)}")
            raise

def main():
    """Основная функция запуска бота"""
    try:
        # Создаем экземпляр бота и запускаем
        bot = ThetaBot()
        bot.run()
        
    except Exception as e:
        logger.error(f"❌ Ошибка при запуске бота: {str(e)}")
        raise

if __name__ == "__main__":
    main() 