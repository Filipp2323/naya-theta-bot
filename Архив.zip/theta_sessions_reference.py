"""
РЕФЕРЕНС РЕАЛИЗАЦИИ БЛОКА ТЕТА-СЕССИЙ
Этот файл содержит правильную реализацию обработки тета-сессий в боте.
НЕ ИЗМЕНЯТЬ без явного указания пользователя!

Основные компоненты:
1. Обработка выбора типа сессии
2. Отправка вопросов
3. Обработка ответа пользователя
4. Показ кнопки "Получить ответ"
"""

# Импорты, необходимые для работы
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
import logging

# Список поддерживаемых типов тета-сессий
THETA_SESSIONS = [
    "🌟 Раскрытие потенциала",
    "❤️ Гармония в отношениях",
    "💰 Финансовое благополучие",
    "🧘‍♀️ Здоровье и энергия"
]

# Стандартные вопросы для всех типов сессий
THETA_QUESTIONS = [
    "1. Какие таланты или способности вы хотели бы развить?",
    "2. Что, по вашему мнению, мешает вам полностью раскрыть свой потенциал?",
    "3. В какой сфере жизни вы чувствуете, что можете достичь большего?"
]

async def handle_session_choice(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обработка выбора типа сессии"""
    try:
        message_text = update.message.text
        
        # Проверяем, является ли сообщение выбором тета-сессии
        if message_text in THETA_SESSIONS:
            # Сохраняем тип сессии и устанавливаем флаг ожидания ответа
            context.user_data['session_context'] = {
                'waiting_for_response': True,
                'questions_asked': True,
                'session_type': message_text
            }
            
            # Формируем сообщение с вопросами
            message = "✨ Для лучшего понимания вашего запроса, ответьте, пожалуйста, на следующие вопросы:\n\n"
            message += "\n".join(THETA_QUESTIONS)
            message += "\n\nОпишите ваш ответ в одном сообщении 📝"
            
            await update.message.reply_text(message)
        
    except Exception as e:
        logger.error(f"Error in handle_session_choice: {e}")
        await self.handle_error(update, BotMessages.ERROR_MESSAGE)

async def handle_user_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обработка сообщений пользователя"""
    try:
        # Получаем текст сообщения
        message_text = update.message.text

        # Проверяем контекст сессии
        session_context = context.user_data.get('session_context', {})
        
        # Если это ответ на вопросы тета-сессии
        if session_context.get('waiting_for_response') and session_context.get('questions_asked'):
            # Сохраняем ответ пользователя
            context.user_data['user_response'] = message_text
            
            # Отправляем сообщение о готовности ответа
            response_message = "Я проанализировала ваш запрос и готова предложить глубокое понимание вашей ситуации. Нажмите кнопку ниже, чтобы получить ответ."
            
            # Создаем клавиатуру с кнопкой "Получить ответ"
            keyboard = BotKeyboards.get_answer_button()
            
            # Отправляем сообщение с кнопкой
            await update.message.reply_text(
                response_message,
                reply_markup=keyboard
            )
            
            # Обновляем контекст
            context.user_data['session_context']['waiting_for_response'] = False
        else:
            # Проверяем, является ли сообщение командой
            handler_name = CommandHandler.get_handler_for_text(message_text)
            if handler_name:
                handler = getattr(self, handler_name, None)
                if handler:
                    await handler(update, context)
                    return
            else:
                # Если сообщение не в контексте сессии
                await update.message.reply_text(
                    "Пожалуйста, выберите тип сессии из меню.",
                    reply_markup=BotKeyboards.get_session_menu()
                )

    except Exception as e:
        logger.error(f"Error in handle_user_message: {e}")
        await self.handle_error(update, BotMessages.ERROR_MESSAGE)

"""
ВАЖНЫЕ ПРИМЕЧАНИЯ:

1. Порядок проверок:
   - Сначала проверяем контекст сессии
   - Потом обрабатываем команды
   - В конце показываем меню

2. Флаги контекста:
   - waiting_for_response: ожидаем ли ответ от пользователя
   - questions_asked: были ли заданы вопросы
   - session_type: тип выбранной сессии

3. Не изменять:
   - Порядок проверок в handle_user_message
   - Структуру контекста сессии
   - Стандартные вопросы
   - Логику показа кнопки "Получить ответ"

4. Сохранение ответа:
   - Ответ сохраняется в context.user_data['user_response']
   - Используется позже для генерации ответа через GPT
""" 