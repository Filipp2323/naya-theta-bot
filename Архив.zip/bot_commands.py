"""
Модуль управления командами и кнопками бота.
Этот модуль содержит все константы и классы для работы с командами и кнопками.
"""
from telegram import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup
from typing import Dict, List, Any
from dataclasses import dataclass

# Константа для проверки целостности меню
MENU_VERSION = "1.0.1"
MENU_CHECKSUM = "f9e4b3a2d1c8"

@dataclass
class CommandConfig:
    """Конфигурация команды"""
    command: str
    description: str
    handler_name: str
    requires_auth: bool = False
    
class BotKeyboards:
    """Класс для управления клавиатурами бота"""
    
    @staticmethod
    def get_main_menu() -> ReplyKeyboardMarkup:
        """Возвращает основное меню"""
        keyboard = [
            ["✨ Начать сессию"],
            ["🧘‍♀️ Медитации", "🌌 Задать вопрос Вселенной"],
            ["📝 Отзывы", "❓ Частые вопросы"],
            ["💬 Задать вопрос Нае"]
        ]
        return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    
    @staticmethod
    def get_session_menu() -> ReplyKeyboardMarkup:
        """Возвращает меню выбора типа сессии"""
        keyboard = [
            ["🌟 Раскрытие потенциала"],
            ["❤️ Гармония в отношениях"],
            ["💰 Финансовое благополучие"],
            ["🧘‍♀️ Здоровье и энергия"],
            ["⬅️ Вернуться в главное меню"]
        ]
        return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

    @staticmethod
    def get_answer_button() -> InlineKeyboardMarkup:
        """Возвращает кнопку для получения ответа"""
        keyboard = [[InlineKeyboardButton("Получить ответ", callback_data="get_answer")]]
        return InlineKeyboardMarkup(keyboard)

class BotMessages:
    """Класс для хранения текстовых сообщений бота"""
    
    START_MESSAGE = (
        "✨ Здравствуйте, дорогой друг!\n\n"
        "Я Ная - ваш проводник в мир глубинных трансформаций и раскрытия истинного потенциала. "
        "Через метод Тета-хилинга я помогаю людям вернуться к своей подлинной сути, "
        "освободиться от ограничивающих убеждений и обрести внутреннюю силу.\n\n"
        "Каждая наша встреча - это путешествие к вашему истинному Я, "
        "где мы вместе исследуем глубины вашей души и открываем новые горизонты возможностей.\n\n"
        "Выберите интересующий вас путь из меню ниже, и давайте начнем это удивительное путешествие вместе! ♥️"
    )
    
    ERROR_MESSAGE = (
        "Простите, произошла небольшая заминка в нашем общении. "
        "Но не волнуйтесь, я всегда готова продолжить наш диалог. "
        "Просто выберите нужный пункт меню, и мы продолжим наше путешествие. ✨"
    )
    
    PROCESSING_MESSAGE = (
        "✨ Я внимательно прислушиваюсь к вашему запросу... "
        "Дайте мне несколько мгновений, чтобы настроиться на вашу энергию."
    )

class CommandHandler:
    """Класс для обработки команд бота"""
    
    # Маппинг текстовых команд к обработчикам
    TEXT_TO_HANDLER = {
        # Основные команды
        "✨ Начать сессию": "start_session",
        "🧘‍♀️ Медитации": "handle_meditations",
        "🌌 Задать вопрос Вселенной": "handle_universe_question",
        "📝 Отзывы": "handle_testimonials",
        "❓ Частые вопросы": "handle_faq",
        "💬 Задать вопрос Нае": "handle_contact_naya",
        "⬅️ Вернуться в главное меню": "start",
        
        # Типы сессий
        "🌟 Раскрытие потенциала": "handle_session_choice",
        "❤️ Гармония в отношениях": "handle_session_choice",
        "💰 Финансовое благополучие": "handle_session_choice",
        "🧘‍♀️ Здоровье и энергия": "handle_session_choice",
        "🎯 Достижение целей": "handle_session_choice",
        "🌈 Очищение от негатива": "handle_session_choice",
        "👥 Родовые программы": "handle_session_choice",
        "✨ Изобилие во всех сферах": "handle_session_choice"
    }
    
    @classmethod
    def get_handler_for_text(cls, text: str) -> str:
        """Возвращает имя обработчика для текстовой команды"""
        return cls.TEXT_TO_HANDLER.get(text)
    
    @classmethod
    def is_valid_command(cls, text: str) -> bool:
        """Проверяет, является ли текст валидной командой"""
        return text in cls.TEXT_TO_HANDLER 